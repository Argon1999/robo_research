# Bare Bones Code to View the Image Published from the Turtlebot3 on a Remote Computer
# Intro to Robotics Research 7785
# Georgia Institute of Technology
# Sean Wilson, 2022

from geometry_msgs.msg import Point
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy, QoSHistoryPolicy

import sys

import numpy as np
import cv2

class FindObject(Node):

	def __init__(self):		
		# Creates the node.
		super().__init__('Object_Finder_Node')

		# Set Parameters
		self.declare_parameter('show_image_bool', False)
		self.declare_parameter('window_name', "Raw Image")

		#Determine Window Showing Based on Input
		self._display_image = bool(self.get_parameter('show_image_bool').value)

		# Declare some variables
		self._titleOriginal = self.get_parameter('window_name').value # Image Window Title	
		
		#Only create image frames if we are not running headless (_display_image sets this)
		if(self._display_image):
		# Set Up Image Viewing
			cv2.namedWindow(self._titleOriginal, cv2.WINDOW_AUTOSIZE ) # Viewing Window
			cv2.moveWindow(self._titleOriginal, 50, 50) # Viewing Window Original Location
		
		#Set up QoS Profiles for passing images over WiFi
		image_qos_profile = QoSProfile(
		    reliability=QoSReliabilityPolicy.BEST_EFFORT,
		    history=QoSHistoryPolicy.KEEP_LAST,
		    durability=QoSDurabilityPolicy.VOLATILE,
		    depth=1
		)

		#Declare that the minimal_video_subscriber node is subcribing to the /camera/image/compressed topic.
		self._video_subscriber = self.create_subscription(
				CompressedImage,
				'/image_raw/compressed',
				self._image_callback,
				image_qos_profile)
		self._video_subscriber # Prevents unused variable warning.
		
		self._location_publisher = self.create_publisher(Point, '/object_location', 10)
		self._location_publisher # Prevents unused variable warning.

	def _image_callback(self, CompressedImage):	
		# The "CompressedImage" is transformed to a color image in BGR space and is store in "_imgBGR"
		# Convert compressed image data to numpy array
		np_arr = np.frombuffer(CompressedImage.data, np.uint8)
		# Decode image using OpenCV
		self._imgBGR = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
		self.find_object()
		
		if(self._display_image):
			# Display the image in a window
			self.show_image(self._imgBGR)
    

	def show_image(self, img):
		cv2.imshow(self._titleOriginal, img)
		# Cause a slight delay so image is displayed
		self._user_input=cv2.waitKey(50) #Use OpenCV keystroke grabber for delay.

	def get_user_input(self):
		return self._user_input
	
	def find_object(self):
		hsv = cv2.cvtColor(self._imgBGR, cv2.COLOR_BGR2HSV)

        # Display the resulting frame

		blue_low = np.array([90,50, 50])
		blue_high = np.array([130, 255, 255])

		mask = cv2.inRange(hsv, blue_low, blue_high)

		kern = np.ones((5,5), np.uint8)
		mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kern)
		mask = cv2.morphologyEx(mask, cv2.MORPH_DILATE, kern)


		cntr, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		count = 0

		for i,c in enumerate(cntr):
			if cv2.contourArea(c) > 2500:
				x,y,w,h = cv2.boundingRect(c)
				msg  = Point()
				msg.x = (x + w) / 2
				msg.y = (y + h) / 2
				msg.z = self._imgBGR.shape[1]/2
				self._location_publisher.publish(msg)


def main():
	rclpy.init() #init routine needed for ROS2.
	video_subscriber = FindObject() #Create class object to be used.

	while rclpy.ok():
		rclpy.spin_once(video_subscriber) # Trigger callback processing.
		if(video_subscriber._display_image):	
			if video_subscriber.get_user_input() == ord('q'):
				cv2.destroyAllWindows()
				break
	rclpy.logging.get_logger("Camera Viewer Node Info...").info("Shutting Down")
	#Clean up and shutdown.
	video_subscriber.destroy_node()  
	rclpy.shutdown()


if __name__ == '__main__':
	main()